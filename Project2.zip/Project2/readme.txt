Project: "Explore US Bikeshare Data"

The websites that I used to work in this project are:

- All the practice problems for this project
- https://es.stackoverflow.com/questions/38288/diferencia-entre-input-y-raw-input
- https://pandas.pydata.org/pandas-docs/stable/reference/api/pandas.DataFrame.groupby.html
- https://www.geeksforgeeks.org/display-the-pandas-dataframe-in-table-style/
- https://www.geeksforgeeks.org/python-while-loops/
- https://www.datacamp.com/community/blog/python-pandas-cheat-sheet



